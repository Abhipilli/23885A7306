import React from 'react';

const ShortenedUrlsTable = ({ urls }) => {
  return (
    <table>
      <thead>
        <tr>
          <th>Original URL</th>
          <th>Shortened URL</th>
        </tr>
      </thead>
      <tbody>
        {urls.map((urlObj, index) => (
          <tr key={index}>
            <td>{urlObj.original}</td>
            <td>{urlObj.shortened}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ShortenedUrlsTable;