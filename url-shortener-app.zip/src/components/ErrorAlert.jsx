import React from 'react';

const ErrorAlert = ({ message }) => {
  return <div style={{ color: 'red' }}>{message}</div>;
};

export default ErrorAlert;