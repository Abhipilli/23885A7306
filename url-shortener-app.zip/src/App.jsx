import React, { useState } from 'react';
import UrlShortenerForm from './components/UrlShortenerForm';
import ShortenedUrlsTable from './components/ShortenedUrlsTable';
import ErrorAlert from './components/ErrorAlert';
import { validateUrl } from './utils/validation';
import { shortenUrl } from './utils/api';
import { logError } from './utils/logging';

const App = () => {
  const [shortenedUrls, setShortenedUrls] = useState([]);
  const [error, setError] = useState('');

  const handleUrlSubmit = async (url) => {
    if (!validateUrl(url)) {
      setError('Invalid URL. Please enter a valid URL.');
      return;
    }

    try {
      const shortenedUrl = await shortenUrl(url);
      setShortenedUrls([...shortenedUrls, shortenedUrl]);
      setError('');
    } catch (err) {
      setError('Failed to shorten URL. Please try again.');
      logError(err);
    }
  };

  return (
    <div>
      <h1>URL Shortener</h1>
      <UrlShortenerForm onSubmit={handleUrlSubmit} />
      {error && <ErrorAlert message={error} />}
      <ShortenedUrlsTable urls={shortenedUrls} />
    </div>
  );
};

export default App;