export const logError = (error) => {
  console.error('Logging error:', error);
};