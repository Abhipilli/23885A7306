export const shortenUrl = async (url) => {
  return {
    original: url,
    shortened: 'http://short.ly/' + Math.random().toString(36).substr(2, 5)
  };
};